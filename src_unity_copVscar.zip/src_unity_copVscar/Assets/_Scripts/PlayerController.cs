﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour {

	[SerializeField] int speed;
	[SerializeField] int rotSpeed;
	Rigidbody rb;

	void Awake(){
		rb = GetComponent<Rigidbody> ();
	}


	Quaternion newRotation = Quaternion.identity;
	// Update is called once per frame
	void Update () {
//		Vector3 angleV;
//		angleV = new Vector3 (0,Input.GetAxisRaw ("Horizontal") , 0);
//
//		Quaternion delta = Quaternion.Euler (angleV * Time.deltaTime * rotSpeed);
//
//		rb.MoveRotation(rb.rotation * delta);
//		rb.MovePosition (transform.position + transform.forward * Time.deltaTime * speed);

		base.transform.Translate(Vector3.forward * this.speed * Time.deltaTime);
		if (Input.GetKey(KeyCode.A))
		{
			base.transform.eulerAngles = new Vector3(0f, base.transform.eulerAngles.y - this.rotSpeed * Time.deltaTime, 0f);
		}
		else if (Input.GetKey(KeyCode.D))
		{
			base.transform.eulerAngles = new Vector3(0f, base.transform.eulerAngles.y + this.rotSpeed * Time.deltaTime, 0f);
		}
	}
}
