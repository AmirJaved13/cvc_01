﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraFollow : MonoBehaviour {

	public Transform target;            		// The target position that that camera will be following.

	public float smoothingSpeed = 0.13f;       	// The speed with which the camera will be following the target.

	public Vector3 offset;   					// Camera offeset


	void FixedUpdate ()
	{
//		Vector3 targetPosition = target.position + offset;
//		Vector3 smoothedPosition = Vector3.Lerp(transform.position, targetPosition, smoothingSpeed);
//		transform.position = smoothedPosition;
	}

	private void Start()
	{
		this.offset = this.target.position - base.transform.position;
	}

	private void LateUpdate()
	{
		base.transform.position = this.target.position - this.offset;
	}
}
