﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Chaser : MonoBehaviour {

	[SerializeField] Transform target;
	[SerializeField] int speed;
	[SerializeField] int rotSpeed;
	Rigidbody rb;

	void Awake(){
		rb = GetComponent<Rigidbody> ();
	}

	Quaternion newRotation = Quaternion.identity;

	// Update is called once per frame
	private void Update()
	{
//		rb.MovePosition (transform.position + transform.forward * Time.deltaTime * speed);
		base.transform.Translate(Vector3.forward * this.speed * Time.deltaTime);
	}

	private void FixedUpdate()
	{
		Vector3 lhs = this.target.position - this.rb.position;
		lhs.Normalize();
		float y = Vector3.Cross(lhs, base.transform.forward).y;
		this.rb.velocity = Vector3.zero;
		this.rb.angularVelocity = new Vector3(0f, -y * this.rotSpeed, 0f);
	}

	void OnTriggerEnter(Collider other){
		if (other.tag == "Player") {
			Debug.Log ("Player");
		} else if (other.tag == "Enemy") {
			Debug.Log ("Enemy");
		} else {
			
		}
	}

	void OnTriggerStay(Collider other){
		if (other.tag == "Player") {

		} else if (other.tag == "Enemy") {

		} else {

		}
	}
}
